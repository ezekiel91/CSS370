document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    const xhr = new XMLHttpRequest();
    const url = 'login.php'; 

    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onload = function() {
        if (this.status === 200) {
            console.log('Response:', this.responseText);
           
        } else {
            console.error('Error:', this.statusText);
        }
    };

    xhr.onerror = function() {
        console.error('Request error...');
    };

    const encodedData = new URLSearchParams(formData).toString();
    xhr.send(encodedData);
});