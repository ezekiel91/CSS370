package com.example.cs370finalproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class VideoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
    }
}